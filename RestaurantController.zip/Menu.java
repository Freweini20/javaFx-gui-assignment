package com.example.javafxfileinputassignment;

import java.util.ArrayList;

public class Menu {
    private final ArrayList<RestaurantItem> menuItems = new ArrayList<>();

    public void addMenuItem(RestaurantItem item) {
        menuItems.add(item);
    }

    public RestaurantItem getItem(int index) {
        return menuItems.get(index);
    }

    @Override
    public String toString() {
        if (menuItems.isEmpty()) {
            return "Menu is empty.";
        }

        StringBuilder output = new StringBuilder("Menu:\n");
        for (int i = 0; i < menuItems.size(); i++) {
            output.append(String.format("%d: %s%n", (i + 1), menuItems.get(i).toString()));
        }

        return output.toString();
    }
}
