package com.example.javafxfileinputassignment;
/*================================================================================================
Author: Freweini Debesay
Class: CSC164
Class Section: 359
Data: 4/20/2026
Assignment: JavaFX II (Events, ListView, File Input) Assignment

I wrote all the code submitted, and I have provided citations and references where appropriate.
==================================================================================================*/

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;



public class RestaurantController {

    @FXML
    private Button drinkButton;

    //stores all menu items loaded from menu.txt file
    private ObservableList<RestaurantItem> observableMenuList = FXCollections.observableArrayList();

    @FXML
    private Button foodButton;

    @FXML
    private Button giftCardButton;

    @FXML
    private ListView<String> menuListView;

    @FXML
    private Button resetButton;

    //Filter and display only Drink items in the listView
    @FXML
    void onDrinkButtonClick(ActionEvent event) {
        List<RestaurantItem> filtered = new ArrayList<>();
        for (int i = 0; i < observableMenuList.size(); i++) {
            if (observableMenuList.get(i) instanceof Drink) {
                filtered.add(observableMenuList.get(i));
            }
        }
        showMenu(filtered);
    }

    //Filter and display only Food items in the listView
    @FXML
    void onFoodButtonClick(ActionEvent event) {
        List<RestaurantItem> filtered = new ArrayList<>();
        for (int i = 0; i < observableMenuList.size(); i++) {
            if (observableMenuList.get(i) instanceof Food) {
                filtered.add(observableMenuList.get(i));
            }
        }
        showMenu(filtered);
    }

    //Filter and display only GiftCard items in the listView
    @FXML
    void onGiftCardButtonClick(ActionEvent event) {
        List<RestaurantItem> filtered = new ArrayList<>();
        for (int i = 0; i < observableMenuList.size(); i++) {
            if (observableMenuList.get(i) instanceof GiftCard) {
                filtered.add(observableMenuList.get(i));
            }
        }
        showMenu(filtered);
    }

    //Resets listView to show all items
    @FXML
    void onResetButtonClick(ActionEvent event) {
        showMenu(observableMenuList);
    }

    public void initialize() {
        readMenuFromFile();
        showMenu(observableMenuList);
    }

    private void readMenuFromFile() {
        try (Scanner keyboard = new Scanner(new File("src/menu.txt"))) {
            while (keyboard.hasNextLine()) {
                String line = keyboard.nextLine();

                //Split the line into parts by using comma
                String[] lineArray = line.split(",");

                //Removes extra spaces from each value
                for (int i = 0; i < lineArray.length; i++) {
                    lineArray[i] = lineArray[i].trim();
                }

                String type = lineArray[0];

                try {
                    if (type.equals("Food")) {
                        String foodName = lineArray[1];
                        double price = Double.parseDouble(lineArray[2]);

                        String allergens = String.join(", ", Arrays.copyOfRange(lineArray, 3, lineArray.length));

                        observableMenuList.add(new Food(foodName, price, allergens));

                    } else if (type.equals("Drink")) {
                        String drinkName = lineArray[1];
                        double price = Double.parseDouble(lineArray[2]);
                        String size = lineArray[3];
                        boolean hasIce = Boolean.parseBoolean(lineArray[4]);

                        observableMenuList.add(new Drink(drinkName, price, size, hasIce));

                    } else if (type.equals("GiftCard")) {
                        String name = lineArray[1];
                        double price = Double.parseDouble(lineArray[2]);
                        double balance = Double.parseDouble(lineArray[3]);

                        String message = String.join(", ", Arrays.copyOfRange(lineArray, 4, lineArray.length));

                        observableMenuList.add(new GiftCard(name, price, balance, message));
                    }

                } catch (NumberFormatException e) {
                    System.out.println("Invalid number format!");
                } catch (IllegalArgumentException e) {
                    System.out.println("Validation error!");
                }
            }

        } catch (FileNotFoundException error) {
            System.out.println("File not found!");
        }
    }

    private void showMenu(List<RestaurantItem> items) {
        //Display given list of items in ListView
        menuListView.getItems().clear();
        for (int i = 0; i < items.size(); i++) {
            menuListView.getItems().add((i + 1) + ". " + items.get(i).toString());
        }
    }
}