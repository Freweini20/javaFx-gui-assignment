package com.example.javafxfileinputassignment;

public class GiftCard extends RestaurantItem {
    private double balance;
    private String message;

    public GiftCard(String name, double price, double balance, String message) {
        super(name, price);
        setBalance(balance);
        setMessage(message);
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        if (balance > 0) {
            this.balance = balance;
        } else {
            throw new IllegalArgumentException("Balance must be positive");
        }
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        if (message != null && !message.trim().isEmpty()) {
            this.message = message;
        } else {
            throw new IllegalArgumentException("message cannot be empty");
        }
    }

    @Override
    public String toString() {
        return super.toString() + " (" +
                "Balance: $" + balance +
                ") - Message: " + message;
    }
}
