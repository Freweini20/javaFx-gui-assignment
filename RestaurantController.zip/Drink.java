package com.example.javafxfileinputassignment;

public class Drink extends RestaurantItem {
    private String size;
    private boolean hasIce;
    public Drink(String name, double price, String size, boolean hasIce) {
        super(name, price);
        setSize(size);
        this.hasIce = hasIce;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        if (size.equalsIgnoreCase("small") || size.equalsIgnoreCase("medium") || size.equalsIgnoreCase("large")) {
            this.size = size;
        } else {
            throw new IllegalArgumentException("size must be either small or medium or large");
        }
    }
    public boolean getHasIce() {
        return hasIce;
    }

    public void setHasIce(boolean hasIce) {
        this.hasIce = hasIce;
    }

    @Override
    public String toString() {
        return super.toString() + " (" + size +
                ", " + (hasIce ? "Ice" : "No Ice") + ") ";
    }
}
