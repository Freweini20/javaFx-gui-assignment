package com.example.javafxfileinputassignment;

public class Food extends RestaurantItem {
    private String allergens;

    public Food(String name, double price, String allergens) {
        super(name, price);
        setAllergens(allergens);
    }

    public String getAllergens() {
        return allergens;
    }

    public void setAllergens(String allergens) {
        if (!allergens.isEmpty()) {
            this.allergens = allergens;
        } else {
            throw new IllegalArgumentException("allergens cannot be empty");
        }
    }

    @Override
    public String toString() {
        return super.toString() +
                "[Allergens: " + allergens +
                "] ";
    }
}
