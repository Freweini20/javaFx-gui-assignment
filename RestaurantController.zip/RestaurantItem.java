package com.example.javafxfileinputassignment;

public class RestaurantItem {
    private String name;
    private double price;

    public RestaurantItem(String name, double price) {
        setName(name);
        setPrice(price);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (!name.isEmpty()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Name cannot be empty");
        }
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price > 0) {
            this.price = price;
        } else {
            throw new IllegalArgumentException("Price must be positive");
        }
    }

    @Override
    public String toString() {
        return String.format("%s ($%.2f) ", name, price);
    }
}
